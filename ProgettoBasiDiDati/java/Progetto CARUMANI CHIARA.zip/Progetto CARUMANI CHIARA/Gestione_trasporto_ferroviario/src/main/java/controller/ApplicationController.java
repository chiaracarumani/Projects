package controller;

import model.domain.*;
import view.ApplicationView;
import view.RegistrationView;

public class ApplicationController implements Controller
{

    Credentials cred;
    Acquirente user;
    GestoriDelServizio gestore;
    Lavoratore lavoratore;
    Manutentore manutentore;

    @Override
    public void start() {
        while(true) {
            int choise = ApplicationView.showApplicationView();
            switch (choise) {
                case 1 -> this.registration();
                case 2 -> this.login();
                default -> throw new RuntimeException("Scelta non valida!");
            }
        }
    }

    private void registration(){

        int type;
        type = RegistrationView.getTypeOfRegistration();

        if(type == 1){

            AcquirenteRegistrationController userRegistrationController = new AcquirenteRegistrationController();
            userRegistrationController.start();
            user = userRegistrationController.getUser();
            cred = userRegistrationController.getCred();
            AcquirenteController acquirenteController = new AcquirenteController();
            acquirenteController.start();

        }

        if(type == 2){
            GestoreRegistrationController gestoreRegistrationController = new GestoreRegistrationController();
            gestoreRegistrationController.start();
            gestore = gestoreRegistrationController.getGestore();
            cred = gestoreRegistrationController.getCred();
            GestoreController gestoreController = new GestoreController();
            gestoreController.start();
        }

        if(type == 3){
            LavoratoreRegistrationController lavoratoreRegistrationController = new LavoratoreRegistrationController();
            lavoratoreRegistrationController.start();
            lavoratore = lavoratoreRegistrationController.getUser();
            cred = lavoratoreRegistrationController.getCred();
            LavoratoreController lavoratoreController = new LavoratoreController();
            lavoratoreController.start();
        }

        if(type == 4){
            ManutentoreRegistrationController manutentoreRegistrationController = new ManutentoreRegistrationController();
            manutentoreRegistrationController.start();
            manutentore = manutentoreRegistrationController.getManutentore();
            cred = manutentoreRegistrationController.getCred();
            ManutentoreController manutentoreController = new ManutentoreController();
            manutentoreController.start();
        }
    }

    private void login(){

        LoginController loginController = new LoginController();
        loginController.start();
        this.cred = loginController.getCred();
        if (this.cred.getRole() == null) {
            throw new RuntimeException("Invalid Credentials");
        } else {
            switch (this.cred.getRole()) {
                case ACQUIRENTE -> (new AcquirenteController()).start();
                case GESTORI_DEL_SERVIZIO -> (new GestoreController()).start();
                case LAVORATORI ->(new LavoratoreController()).start();
                case MANUTENTORE ->(new ManutentoreController()).start();
                default -> throw new RuntimeException("Invalid Credentials");
            }



        }
    }



}
