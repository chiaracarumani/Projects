package model.dao;

import exception.DAOException;
import model.domain.Manutentore;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;

public class ManutentoreRegisterProcedureDAO {

    private static ManutentoreRegisterProcedureDAO registerDAO = null;

    private ManutentoreRegisterProcedureDAO() {
    }

    public static ManutentoreRegisterProcedureDAO getInstance() {
        if (registerDAO == null) {
            registerDAO = new ManutentoreRegisterProcedureDAO();
        }

        return registerDAO;
    }

    public Boolean execute(Object... params) throws DAOException {
        Manutentore manutentore = (Manutentore) params[0];

        try {
            Connection connection = ConnectionFactory.getConnection();
            CallableStatement callableStatement = connection.prepareCall("{call registrazione(?,?,?,?,?,?,?,?,?)}");

            callableStatement.setNull(1, Types.VARCHAR); // codice fiscale
            callableStatement.setNull(2, Types.VARCHAR); // nome
            callableStatement.setNull(3, Types.VARCHAR); // cognome
            callableStatement.setNull(4, Types.DATE);    // data di nascita
            callableStatement.setNull(5, Types.BIGINT);  // numero carta

            callableStatement.setString(6, manutentore.getUsername());
            callableStatement.setString(7, manutentore.getPassword());

            callableStatement.setInt(8, 4);
            callableStatement.setNull(9, Types.VARCHAR);
            callableStatement.executeQuery();

        } catch (SQLException var5) {
            throw new DAOException("Error: " + var5.getMessage());
        }

        return true;
    }
}
