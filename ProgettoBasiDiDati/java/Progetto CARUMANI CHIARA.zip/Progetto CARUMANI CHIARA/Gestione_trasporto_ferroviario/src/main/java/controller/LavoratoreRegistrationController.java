package controller;

import exception.DAOException;
import model.dao.LavoratoreRegisterProcedureDAO;
import model.domain.Credentials;
import model.domain.Lavoratore;
import view.LavoratoreRegistrazione;

import java.io.IOException;

public class LavoratoreRegistrationController {

    private Boolean flag;
    private Credentials cred = null;
    private Lavoratore user;

    public LavoratoreRegistrationController() {
    }


    public void start() {
        try {
            this.cred = LavoratoreRegistrazione.register();
            this.user = LavoratoreRegistrazione.setUserInfo(this.cred);
        } catch (IOException var3) {
            throw new RuntimeException(var3);
        }

        try {
            LavoratoreRegisterProcedureDAO registerProcedureDAO = LavoratoreRegisterProcedureDAO.getInstance();
            this.flag = registerProcedureDAO.execute(new Object[]{this.user});
        } catch (DAOException var2) {
            throw new RuntimeException(var2);
        }

        if (this.flag) {
            System.out.println("Registrazione avvenuta con successo!");
        }

    }



    public Credentials getCred() {
        return this.cred;
    }

    public Lavoratore getUser() {
        return this.user;
    }
}
