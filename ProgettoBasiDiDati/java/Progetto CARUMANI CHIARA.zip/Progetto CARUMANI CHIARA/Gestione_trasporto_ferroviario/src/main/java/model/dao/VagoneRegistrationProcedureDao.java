package model.dao;

import exception.DAOException;
import model.domain.Vagone;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;

public class VagoneRegistrationProcedureDao implements GenericProcedureDAO<Boolean> {

    private static VagoneRegistrationProcedureDao instance = null;

    private VagoneRegistrationProcedureDao() {}

    public static VagoneRegistrationProcedureDao getInstance() {
        if (instance == null) {
            instance = new VagoneRegistrationProcedureDao();
        }
        return instance;
    }

    @Override
    public Boolean execute(Object... params) throws DAOException {
        Vagone vagone = (Vagone) params[0];

        try (Connection connection = ConnectionFactory.getConnection();
             CallableStatement callableStatement = connection.prepareCall("{call registra_vagone(?,?,?,?,?,?)}")) {

            callableStatement.setString(1, vagone.getCodice());
            callableStatement.setString(2, vagone.getMarca());
            callableStatement.setInt(3, vagone.getClasse());
            callableStatement.setString(4, vagone.getModello());
            callableStatement.setInt(5, vagone.getMaxPasseggeri());
            callableStatement.setString(6, vagone.getMatricolaTreno().trim());

            callableStatement.execute();

        } catch (SQLException e) {
            throw new DAOException("Errore nella registrazione del vagone: " + e.getMessage(), e);
        }

        return true;
    }
}
