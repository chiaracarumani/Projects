package model.dao;

import exception.DAOException;
import model.domain.GestoriDelServizio;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;

public class GestoreRegisterProcedureDAO {

    private static GestoreRegisterProcedureDAO registerDAO = null;

    private GestoreRegisterProcedureDAO() {
    }

    public static GestoreRegisterProcedureDAO getInstance() {
        if (registerDAO == null) {
            registerDAO = new GestoreRegisterProcedureDAO();
        }

        return registerDAO;
    }

    public Boolean execute(Object... params) throws DAOException {
        GestoriDelServizio gestore = (GestoriDelServizio) params[0];

        try {
            Connection connection = ConnectionFactory.getConnection();
            CallableStatement callableStatement = connection.prepareCall("{call registrazione(?,?,?,?,?,?,?,?,?)}");

            callableStatement.setNull(1, Types.VARCHAR); // codice fiscale
            callableStatement.setNull(2, Types.VARCHAR); // nome
            callableStatement.setNull(3, Types.VARCHAR); // cognome
            callableStatement.setNull(4, Types.DATE);    // data di nascita
            callableStatement.setNull(5, Types.BIGINT);  // numero carta

            callableStatement.setString(6, gestore.getUsername());
            callableStatement.setString(7, gestore.getPassword());

            callableStatement.setInt(8, 2);              // ruolo: 2 = gestore
            callableStatement.setNull(9, Types.VARCHAR); // ruolo lavoratore → null

            callableStatement.executeQuery();

        } catch (SQLException var5) {
            throw new DAOException("Error: " + var5.getMessage());
        }



        return true;
    }
}


