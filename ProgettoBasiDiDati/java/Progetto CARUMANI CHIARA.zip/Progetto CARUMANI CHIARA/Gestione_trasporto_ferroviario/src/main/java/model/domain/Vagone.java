package model.domain;

public class Vagone {
    private String codice; // <-- era int id
    private String modello;
    private int classe;
    private String marca;
    private int maxPasseggeri;
    private String matricolaTreno;

    public Vagone() {}

    public Vagone(String codice, String modello, int classe, String marca, int maxPasseggeri, String matricolaTreno){
        this.codice = codice;
        this.modello = modello;
        this.classe = classe;
        this.marca = marca;
        this.maxPasseggeri = maxPasseggeri;
        this.matricolaTreno = matricolaTreno;
    }

    public String getCodice() {
        return codice;
    }
    public void setCodice(String codice) {
        this.codice = codice;
    }

    public String getModello() {
        return modello;
    }
    public void setModello(String modello) {
        this.modello = modello;
    }

    public String getMarca() {
        return marca;
    }
    public void setMarca(String marca) {
        this.marca = marca;
    }

    public int getClasse() {
        return classe;
    }
    public void setClasse(int classe) {
        this.classe = classe;
    }

    public int getMaxPasseggeri() {
        return maxPasseggeri;
    }
    public void setMaxPasseggeri(int maxPasseggeri) {
        this.maxPasseggeri = maxPasseggeri;
    }

    public String getMatricolaTreno() {
        return matricolaTreno;
    }
    public void setMatricolaTreno(String matricolaTreno) {
        this.matricolaTreno = matricolaTreno;
    }
}
