package controller;

import exception.DAOException;
import model.dao.ManutentoreRegisterProcedureDAO;
import model.domain.Credentials;
import model.domain.Manutentore;
import view.ManutentoreRegistrazione;

import java.io.IOException;

public class ManutentoreRegistrationController {
    private Boolean flag;
    private Credentials cred = null;
    private Manutentore manutentore;

    public ManutentoreRegistrationController() {
    }

    public void start() {
        try {
            this.cred = ManutentoreRegistrazione.register();
            this.manutentore = ManutentoreRegistrazione.creaManutentore(cred.getUsername(), cred.getPassword());
        } catch (IOException var3) {
            throw new RuntimeException(var3);
        }

        try {
            ManutentoreRegisterProcedureDAO registerProcedureDAO = ManutentoreRegisterProcedureDAO.getInstance();
            this.flag = registerProcedureDAO.execute(new Object[]{this.manutentore});
        } catch (DAOException var2) {
            throw new RuntimeException(var2);
        }

        if (this.flag) {
            System.out.println("Registrazione avvenuta con successo!");
        }

    }

    public Credentials getCred() {
        return this.cred;
    }

    public Manutentore getManutentore() {
        return this.manutentore;
    }
}
