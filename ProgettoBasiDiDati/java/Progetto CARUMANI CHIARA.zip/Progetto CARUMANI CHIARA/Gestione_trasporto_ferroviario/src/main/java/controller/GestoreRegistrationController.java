package controller;

import exception.DAOException;
import model.dao.GestoreRegisterProcedureDAO;
import model.domain.Credentials;
import model.domain.GestoriDelServizio;
import view.GestoreRegistrazione;

import java.io.IOException;

public class GestoreRegistrationController {
    private Boolean flag;
    private Credentials cred = null;
    private GestoriDelServizio gestore;

    public GestoreRegistrationController() {
    }

    public void start() {
        try {
            this.cred = GestoreRegistrazione.register();
            this.gestore = GestoreRegistrazione.creaGestore(cred.getUsername(), cred.getPassword());
        } catch (IOException var3) {
            throw new RuntimeException(var3);
        }

        try {
            GestoreRegisterProcedureDAO registerProcedureDAO = GestoreRegisterProcedureDAO.getInstance();
            this.flag = registerProcedureDAO.execute(new Object[]{this.gestore});
        } catch (DAOException var2) {
            throw new RuntimeException(var2);
        }

        if (this.flag) {
            System.out.println("Registrazione avvenuta con successo!");
        }

    }

    public Credentials getCred() {
        return this.cred;
    }

    public GestoriDelServizio getGestore() {
        return this.gestore;
    }
}

