package model.dao;

import exception.DAOException;
import model.domain.Acquirente;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;

public class AcquirenteRegisterProcedureDAO implements GenericProcedureDAO<Boolean> {
    private static AcquirenteRegisterProcedureDAO registerDAO = null;

    private AcquirenteRegisterProcedureDAO() {
    }

    public static AcquirenteRegisterProcedureDAO getInstance() {
        if (registerDAO == null) {
            registerDAO = new AcquirenteRegisterProcedureDAO();
        }

        return registerDAO;
    }

    public Boolean execute(Object... params) throws DAOException {
        Acquirente user = (Acquirente) params[0];
        Connection connection = null;
        CallableStatement callableStatement = null;

        try {
            connection = ConnectionFactory.getConnection();
            callableStatement = connection.prepareCall("{call registrazione(?,?,?,?,?,?,?,?,?)}");

            callableStatement.setString(1, user.getCodiceFiscale());
            callableStatement.setString(2, user.getNome());
            callableStatement.setString(3, user.getCognome());
            callableStatement.setDate(4, user.getDataDiNascita());
            callableStatement.setString(5, user.getNumeroCartaDiCredito());
            callableStatement.setString(6, user.getUsername());
            callableStatement.setString(7, user.getPassword());

            callableStatement.setInt(8, 1);           // ruolo 1 = acquirente
            callableStatement.setString(9, null);     // non serve per acquirente

            callableStatement.execute();

        } catch (SQLException e) {
            throw new DAOException("Errore nella registrazione dell'acquirente: " + e.getMessage());
        } finally {
            try {
                if (callableStatement != null) callableStatement.close();
                if (connection != null) connection.close();
            } catch (SQLException ignored) {}
        }

        return true;
    }
}

