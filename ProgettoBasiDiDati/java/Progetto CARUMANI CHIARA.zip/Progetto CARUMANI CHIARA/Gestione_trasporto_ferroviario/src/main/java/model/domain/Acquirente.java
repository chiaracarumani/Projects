package model.domain;

import java.sql.Date;

public class Acquirente {
    private String codiceFiscale;
    private String nome;
    private String cognome;
    private Date dataDiNascita;
    private String numeroCartaDiCredito;
    private Date dataDiScadenzaCartaDiCredito;
    private String username;
    private String password;

    public Acquirente() {}

    public Acquirente(String codiceFiscale, String nome, String cognome, Date dataDiNascita,
                      String numeroCartaDiCredito, String username, String password,
                      Date dataDiScadenzaCartaDiCredito) {
        this.codiceFiscale = codiceFiscale;
        this.nome = nome;
        this.cognome = cognome;
        this.dataDiNascita = dataDiNascita;
        this.numeroCartaDiCredito = numeroCartaDiCredito;
        this.username = username;
        this.password = password;
        this.dataDiScadenzaCartaDiCredito = dataDiScadenzaCartaDiCredito;
    }

    public String getCodiceFiscale() {
        return codiceFiscale;
    }

    public void setCodiceFiscale(String codiceFiscale) {
        this.codiceFiscale = codiceFiscale;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCognome() {
        return cognome;
    }

    public void setCognome(String cognome) {
        this.cognome = cognome;
    }

    public Date getDataDiNascita() {
        return dataDiNascita;
    }

    public void setDataDiNascita(Date dataDiNascita) {
        this.dataDiNascita = dataDiNascita;
    }

    public String getNumeroCartaDiCredito() {
        return numeroCartaDiCredito;
    }

    public void setNumeroCartaDiCredito(String numeroCartaDiCredito) {
        this.numeroCartaDiCredito = numeroCartaDiCredito;
    }

    public Date getdataDiScadenzaCartaDiCredito() {
        return dataDiScadenzaCartaDiCredito;
    }

    public void setdataDiScadenzaCartaDiCredito(Date dataDiScadenzaCartaDiCredito) {
        this.dataDiScadenzaCartaDiCredito = dataDiScadenzaCartaDiCredito;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}

