package view;

import model.domain.Credentials;
import model.domain.Manutentore;
import model.domain.Role;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class ManutentoreRegistrazione {

    public ManutentoreRegistrazione() {
    }

    public static Credentials register() throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Inserisci un username: ");
        String username = reader.readLine();
        System.out.println("Inserisci una password: ");
        String password = reader.readLine();
        return new Credentials(username, password, Role.MANUTENTORE);
    }

    public static Manutentore creaManutentore(String username, String password) {
        return new Manutentore(username, password);
    }

}
