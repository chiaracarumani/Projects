package view;

import model.domain.Credentials;
import model.domain.GestoriDelServizio;
import model.domain.Role;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class GestoreRegistrazione {

    public GestoreRegistrazione() {
    }

    public static Credentials register() throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Inserisci un username: ");
        String username = reader.readLine();
        System.out.println("Inserisci una password: ");
        String password = reader.readLine();
        return new Credentials(username, password, Role.GESTORI_DEL_SERVIZIO);
    }

    // ✅ Versione corretta: non richiede nulla, riceve già i dati
    public static GestoriDelServizio creaGestore(String username, String password) {
        return new GestoriDelServizio(username, password);
    }
}

