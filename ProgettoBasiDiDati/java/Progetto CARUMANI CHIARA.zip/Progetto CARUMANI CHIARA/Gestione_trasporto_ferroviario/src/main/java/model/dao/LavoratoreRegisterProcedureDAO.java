package model.dao;

import exception.DAOException;
import model.domain.Lavoratore;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;

public class LavoratoreRegisterProcedureDAO implements GenericProcedureDAO<Boolean>{
    private static LavoratoreRegisterProcedureDAO registerDAO = null;

    private LavoratoreRegisterProcedureDAO() {
    }

    public static LavoratoreRegisterProcedureDAO getInstance() {
        if (registerDAO == null) {
            registerDAO = new LavoratoreRegisterProcedureDAO();
        }

        return registerDAO;
    }

    public Boolean execute(Object... params) throws DAOException {
        Lavoratore lavoratore = (Lavoratore) params[0];

        try (Connection connection = ConnectionFactory.getConnection();
             CallableStatement callableStatement = connection.prepareCall("{call registrazione(?,?,?,?,?,?,?,?,?)}")) {

            callableStatement.setString(1, lavoratore.getCodiceFiscale());
            callableStatement.setString(2, lavoratore.getNome());
            callableStatement.setString(3, lavoratore.getCognome());
            callableStatement.setDate(4, lavoratore.getDataDiNascita());
            callableStatement.setNull(5, Types.BIGINT); // Nessuna carta di credito per lavoratori
            callableStatement.setString(6, lavoratore.getUsername());
            callableStatement.setString(7, lavoratore.getPassword());
            callableStatement.setInt(8, 3); // Ruolo lavoratore
            callableStatement.setString(9, lavoratore.getRuolo()); // "macchinista" o "capotreno"

            callableStatement.execute();

        } catch (SQLException var5) {
            throw new DAOException("Error: " + var5.getMessage());
        }
        return true;
    }
}